package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class SampleController {
	
	@FXML Button bt_copy;
	@FXML Button bt_clear;
	@FXML Button bt_save;
	
	
	
	
	@FXML
	protected void save(ActionEvent event) {
		System.out.println(" in  save ");
	}
	
	
	@FXML
	protected void copy(ActionEvent event) {
		System.out.println(" in  copy ");
	}
	
	@FXML
	protected void clear(ActionEvent event) {
		System.out.println(" in  clear ");
	}
}
